export interface Template {
  id: string
  name: string
  description: string
  category: string
  preview: string
  files: {
    "index.html": string
    "style.css": string
    "script.js": string
  }
  framework: "vanilla" | "react" | "vue" | "svelte"
}

export const templates: Template[] = [
  {
    id: "landing-modern",
    name: "Landing Page Moderna",
    description: "Una landing page elegante con animaciones y diseño responsive",
    category: "Marketing",
    preview: "/placeholder.svg?height=200&width=300",
    framework: "vanilla",
    files: {
      "index.html": `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page Moderna</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h2>TuMarca</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="#inicio">Inicio</a></li>
                <li><a href="#servicios">Servicios</a></li>
                <li><a href="#contacto">Contacto</a></li>
            </ul>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-container">
            <h1 class="hero-title">Construye el futuro con nosotros</h1>
            <p class="hero-subtitle">Soluciones innovadoras para tu negocio</p>
            <button class="cta-button">Comenzar Ahora</button>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <h2>Nuestros Servicios</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <h3>Desarrollo Web</h3>
                    <p>Sitios web modernos y responsivos</p>
                </div>
                <div class="feature-card">
                    <h3>Aplicaciones Móviles</h3>
                    <p>Apps nativas e híbridas</p>
                </div>
                <div class="feature-card">
                    <h3>Consultoría</h3>
                    <p>Estrategias digitales efectivas</p>
                </div>
            </div>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>`,
      "style.css": `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
}

.navbar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 1000;
    padding: 1rem 0;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 2rem;
}

.nav-logo h2 {
    color: #6366f1;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-menu a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: color 0.3s;
}

.nav-menu a:hover {
    color: #6366f1;
}

.hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: white;
}

.hero-container {
    max-width: 800px;
    padding: 0 2rem;
}

.hero-title {
    font-size: 3.5rem;
    margin-bottom: 1rem;
    animation: fadeInUp 1s ease;
}

.hero-subtitle {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    opacity: 0.9;
    animation: fadeInUp 1s ease 0.2s both;
}

.cta-button {
    background: #fff;
    color: #6366f1;
    border: none;
    padding: 1rem 2rem;
    font-size: 1.1rem;
    font-weight: bold;
    border-radius: 50px;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    animation: fadeInUp 1s ease 0.4s both;
}

.cta-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.features {
    padding: 5rem 0;
    background: #f8fafc;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

.features h2 {
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 3rem;
    color: #333;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.feature-card {
    background: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
    transition: transform 0.3s;
}

.feature-card:hover {
    transform: translateY(-5px);
}

.feature-card h3 {
    color: #6366f1;
    margin-bottom: 1rem;
    font-size: 1.5rem;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 768px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.2rem;
    }
    
    .nav-menu {
        display: none;
    }
}`,
      "script.js": `// Smooth scrolling para navegación
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animación de aparición en scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observar elementos para animación
document.querySelectorAll('.feature-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
});

// Efecto parallax en hero
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    if (hero) {
        hero.style.transform = \`translateY(\${scrolled * 0.5}px)\`;
    }
});

console.log('Landing page moderna cargada correctamente!');`,
    },
  },
  {
    id: "dashboard-admin",
    name: "Dashboard Admin",
    description: "Panel de administración con gráficos y métricas",
    category: "Admin",
    preview: "/placeholder.svg?height=200&width=300",
    framework: "vanilla",
    files: {
      "index.html": `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-item active">
                    <span class="icon">📊</span>
                    Dashboard
                </a>
                <a href="#" class="nav-item">
                    <span class="icon">👥</span>
                    Usuarios
                </a>
                <a href="#" class="nav-item">
                    <span class="icon">📈</span>
                    Analytics
                </a>
                <a href="#" class="nav-item">
                    <span class="icon">⚙️</span>
                    Configuración
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <header class="header">
                <h1>Dashboard</h1>
                <div class="user-info">
                    <span>Bienvenido, Admin</span>
                    <div class="avatar">A</div>
                </div>
            </header>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Usuarios Totales</h3>
                    <div class="stat-number">1,234</div>
                    <div class="stat-change positive">+12%</div>
                </div>
                <div class="stat-card">
                    <h3>Ventas</h3>
                    <div class="stat-number">$45,678</div>
                    <div class="stat-change positive">+8%</div>
                </div>
                <div class="stat-card">
                    <h3>Pedidos</h3>
                    <div class="stat-number">567</div>
                    <div class="stat-change negative">-3%</div>
                </div>
                <div class="stat-card">
                    <h3>Conversión</h3>
                    <div class="stat-number">3.2%</div>
                    <div class="stat-change positive">+0.5%</div>
                </div>
            </div>

            <div class="charts-section">
                <div class="chart-container">
                    <h3>Ventas por Mes</h3>
                    <canvas id="salesChart"></canvas>
                </div>
                <div class="recent-activity">
                    <h3>Actividad Reciente</h3>
                    <div class="activity-list">
                        <div class="activity-item">
                            <span class="activity-icon">👤</span>
                            <div class="activity-content">
                                <p>Nuevo usuario registrado</p>
                                <small>Hace 5 minutos</small>
                            </div>
                        </div>
                        <div class="activity-item">
                            <span class="activity-icon">💰</span>
                            <div class="activity-content">
                                <p>Venta completada - $299</p>
                                <small>Hace 15 minutos</small>
                            </div>
                        </div>
                        <div class="activity-item">
                            <span class="activity-icon">📦</span>
                            <div class="activity-content">
                                <p>Pedido enviado #1234</p>
                                <small>Hace 1 hora</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="script.js"></script>
</body>
</html>`,
      "style.css": `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
    color: #333;
}

.dashboard {
    display: flex;
    height: 100vh;
}

.sidebar {
    width: 250px;
    background: #2d3748;
    color: white;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    padding: 1.5rem;
    border-bottom: 1px solid #4a5568;
}

.sidebar-header h2 {
    color: #63b3ed;
}

.sidebar-nav {
    flex: 1;
    padding: 1rem 0;
}

.nav-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 1.5rem;
    color: #a0aec0;
    text-decoration: none;
    transition: all 0.3s;
}

.nav-item:hover,
.nav-item.active {
    background: #4a5568;
    color: white;
}

.nav-item .icon {
    margin-right: 0.75rem;
    font-size: 1.2rem;
}

.main-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.header {
    background: white;
    padding: 1.5rem 2rem;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.avatar {
    width: 40px;
    height: 40px;
    background: #63b3ed;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    padding: 2rem;
}

.stat-card {
    background: white;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stat-card h3 {
    color: #718096;
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.stat-number {
    font-size: 2rem;
    font-weight: bold;
    color: #2d3748;
    margin-bottom: 0.5rem;
}

.stat-change {
    font-size: 0.9rem;
    font-weight: 500;
}

.stat-change.positive {
    color: #38a169;
}

.stat-change.negative {
    color: #e53e3e;
}

.charts-section {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
    padding: 0 2rem 2rem;
    flex: 1;
}

.chart-container,
.recent-activity {
    background: white;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.chart-container h3,
.recent-activity h3 {
    margin-bottom: 1rem;
    color: #2d3748;
}

#salesChart {
    width: 100%;
    height: 300px;
    background: linear-gradient(45deg, #63b3ed, #4299e1);
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
}

.activity-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.75rem;
    background: #f7fafc;
    border-radius: 6px;
}

.activity-icon {
    font-size: 1.5rem;
}

.activity-content p {
    font-weight: 500;
    margin-bottom: 0.25rem;
}

.activity-content small {
    color: #718096;
}

@media (max-width: 768px) {
    .dashboard {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
    }
    
    .charts-section {
        grid-template-columns: 1fr;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
}`,
      "script.js": `// Simulación de datos en tiempo real
function updateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        const currentValue = parseInt(stat.textContent.replace(/[^0-9]/g, ''));
        const variation = Math.floor(Math.random() * 10) - 5;
        const newValue = Math.max(0, currentValue + variation);
        
        if (stat.textContent.includes('$')) {
            stat.textContent = \`$\${newValue.toLocaleString()}\`;
        } else if (stat.textContent.includes('%')) {
            stat.textContent = \`\${(newValue / 100).toFixed(1)}%\`;
        } else {
            stat.textContent = newValue.toLocaleString();
        }
    });
}

// Navegación activa
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Remover clase active de todos los items
        document.querySelectorAll('.nav-item').forEach(nav => {
            nav.classList.remove('active');
        });
        
        // Agregar clase active al item clickeado
        item.classList.add('active');
    });
});

// Simulación de gráfico
const canvas = document.getElementById('salesChart');
if (canvas) {
    canvas.innerHTML = 'Gráfico de Ventas (Demo)';
    canvas.style.cursor = 'pointer';
    
    canvas.addEventListener('click', () => {
        canvas.style.background = \`linear-gradient(45deg, #\${Math.floor(Math.random()*16777215).toString(16)}, #\${Math.floor(Math.random()*16777215).toString(16)})\`;
    });
}

// Actualizar estadísticas cada 5 segundos
setInterval(updateStats, 5000);

// Animación de entrada
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.stat-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
});

console.log('Dashboard admin cargado correctamente!');`,
    },
  },
  {
    id: "portfolio-creative",
    name: "Portfolio Creativo",
    description: "Portfolio personal con animaciones y efectos visuales",
    category: "Portfolio",
    preview: "/placeholder.svg?height=200&width=300",
    framework: "vanilla",
    files: {
      "index.html": `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio Creativo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="cursor"></div>
    
    <nav class="navbar">
        <div class="nav-brand">Portfolio</div>
        <ul class="nav-links">
            <li><a href="#home">Inicio</a></li>
            <li><a href="#about">Sobre Mí</a></li>
            <li><a href="#projects">Proyectos</a></li>
            <li><a href="#contact">Contacto</a></li>
        </ul>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">
                <span class="line">Hola, soy</span>
                <span class="line">Desarrollador</span>
                <span class="line">Creativo</span>
            </h1>
            <p class="hero-subtitle">Creando experiencias digitales únicas</p>
            <button class="cta-btn">Ver mi trabajo</button>
        </div>
        <div class="hero-visual">
            <div class="floating-shapes">
                <div class="shape shape-1"></div>
                <div class="shape shape-2"></div>
                <div class="shape shape-3"></div>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">Sobre Mí</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>Soy un desarrollador apasionado por crear experiencias web innovadoras. Me especializo en frontend con un enfoque en diseño y usabilidad.</p>
                    <div class="skills">
                        <div class="skill">
                            <span>JavaScript</span>
                            <div class="skill-bar">
                                <div class="skill-progress" data-width="90%"></div>
                            </div>
                        </div>
                        <div class="skill">
                            <span>React</span>
                            <div class="skill-bar">
                                <div class="skill-progress" data-width="85%"></div>
                            </div>
                        </div>
                        <div class="skill">
                            <span>CSS/SASS</span>
                            <div class="skill-bar">
                                <div class="skill-progress" data-width="95%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <div class="image-placeholder">👨‍💻</div>
                </div>
            </div>
        </div>
    </section>

    <section id="projects" class="projects">
        <div class="container">
            <h2 class="section-title">Mis Proyectos</h2>
            <div class="projects-grid">
                <div class="project-card">
                    <div class="project-image">🌐</div>
                    <div class="project-content">
                        <h3>E-commerce App</h3>
                        <p>Aplicación de comercio electrónico con React y Node.js</p>
                        <div class="project-tech">
                            <span>React</span>
                            <span>Node.js</span>
                            <span>MongoDB</span>
                        </div>
                    </div>
                </div>
                <div class="project-card">
                    <div class="project-image">📱</div>
                    <div class="project-content">
                        <h3>Mobile Dashboard</h3>
                        <p>Dashboard responsivo para gestión de datos</p>
                        <div class="project-tech">
                            <span>Vue.js</span>
                            <span>Chart.js</span>
                            <span>Firebase</span>
                        </div>
                    </div>
                </div>
                <div class="project-card">
                    <div class="project-image">🎨</div>
                    <div class="project-content">
                        <h3>Creative Portfolio</h3>
                        <p>Portfolio interactivo con animaciones CSS</p>
                        <div class="project-tech">
                            <span>HTML5</span>
                            <span>CSS3</span>
                            <span>JavaScript</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Contacto</h2>
            <div class="contact-content">
                <div class="contact-info">
                    <h3>¡Hablemos!</h3>
                    <p>¿Tienes un proyecto en mente? Me encantaría escuchar tus ideas.</p>
                    <div class="contact-links">
                        <a href="mailto:hello@portfolio.com">📧 hello@portfolio.com</a>
                        <a href="tel:+1234567890">📞 +123 456 7890</a>
                        <a href="#">💼 LinkedIn</a>
                        <a href="#">🐙 GitHub</a>
                    </div>
                </div>
                <form class="contact-form">
                    <input type="text" placeholder="Tu nombre" required>
                    <input type="email" placeholder="Tu email" required>
                    <textarea placeholder="Tu mensaje" rows="5" required></textarea>
                    <button type="submit">Enviar Mensaje</button>
                </form>
            </div>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>`,
      "style.css": `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
    overflow-x: hidden;
    cursor: none;
}

.cursor {
    width: 20px;
    height: 20px;
    border: 2px solid #6366f1;
    border-radius: 50%;
    position: fixed;
    pointer-events: none;
    z-index: 9999;
    transition: transform 0.1s ease;
}

.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 1000;
}

.nav-brand {
    font-size: 1.5rem;
    font-weight: bold;
    color: #6366f1;
}

.nav-links {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-links a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: color 0.3s;
}

.nav-links a:hover {
    color: #6366f1;
}

.hero {
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 5%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    position: relative;
    overflow: hidden;
}

.hero-content {
    flex: 1;
    max-width: 600px;
}

.hero-title {
    font-size: 4rem;
    font-weight: bold;
    margin-bottom: 1rem;
    overflow: hidden;
}

.hero-title .line {
    display: block;
    transform: translateY(100%);
    animation: slideUp 1s ease forwards;
}

.hero-title .line:nth-child(2) {
    animation-delay: 0.2s;
}

.hero-title .line:nth-child(3) {
    animation-delay: 0.4s;
}

.hero-subtitle {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    opacity: 0;
    animation: fadeIn 1s ease 0.6s forwards;
}

.cta-btn {
    background: white;
    color: #6366f1;
    border: none;
    padding: 1rem 2rem;
    font-size: 1.1rem;
    font-weight: bold;
    border-radius: 50px;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    opacity: 0;
    animation: fadeIn 1s ease 0.8s forwards;
}

.cta-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
}

.hero-visual {
    flex: 1;
    position: relative;
    height: 100%;
}

.floating-shapes {
    position: absolute;
    width: 100%;
    height: 100%;
}

.shape {
    position: absolute;
    border-radius: 50%;
    animation: float 6s ease-in-out infinite;
}

.shape-1 {
    width: 100px;
    height: 100px;
    background: rgba(255, 255, 255, 0.1);
    top: 20%;
    right: 20%;
    animation-delay: 0s;
}

.shape-2 {
    width: 150px;
    height: 150px;
    background: rgba(255, 255, 255, 0.05);
    top: 60%;
    right: 40%;
    animation-delay: 2s;
}

.shape-3 {
    width: 80px;
    height: 80px;
    background: rgba(255, 255, 255, 0.15);
    top: 40%;
    right: 10%;
    animation-delay: 4s;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

.section-title {
    font-size: 3rem;
    text-align: center;
    margin-bottom: 3rem;
    color: #333;
}

.about {
    padding: 5rem 0;
    background: #f8fafc;
}

.about-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: center;
}

.about-text p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
    color: #666;
}

.skills {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.skill {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.skill span {
    font-weight: bold;
    color: #333;
}

.skill-bar {
    height: 8px;
    background: #e2e8f0;
    border-radius: 4px;
    overflow: hidden;
}

.skill-progress {
    height: 100%;
    background: linear-gradient(90deg, #6366f1, #8b5cf6);
    width: 0;
    transition: width 2s ease;
}

.about-image {
    display: flex;
    justify-content: center;
    align-items: center;
}

.image-placeholder {
    width: 200px;
    height: 200px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
    color: white;
}

.projects {
    padding: 5rem 0;
}

.projects-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
}

.project-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: transform 0.3s, box-shadow 0.3s;
}

.project-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}

.project-image {
    height: 200px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
    color: white;
}

.project-content {
    padding: 2rem;
}

.project-content h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: #333;
}

.project-content p {
    color: #666;
    margin-bottom: 1rem;
}

.project-tech {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.project-tech span {
    background: #6366f1;
    color: white;
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.8rem;
}

.contact {
    padding: 5rem 0;
    background: #f8fafc;
}

.contact-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
}

.contact-info h3 {
    font-size: 2rem;
    margin-bottom: 1rem;
    color: #333;
}

.contact-info p {
    font-size: 1.2rem;
    color: #666;
    margin-bottom: 2rem;
}

.contact-links {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.contact-links a {
    color: #6366f1;
    text-decoration: none;
    font-size: 1.1rem;
    transition: color 0.3s;
}

.contact-links a:hover {
    color: #4f46e5;
}

.contact-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.contact-form input,
.contact-form textarea {
    padding: 1rem;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s;
}

.contact-form input:focus,
.contact-form textarea:focus {
    outline: none;
    border-color: #6366f1;
}

.contact-form button {
    background: #6366f1;
    color: white;
    border: none;
    padding: 1rem;
    font-size: 1.1rem;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
}

.contact-form button:hover {
    background: #4f46e5;
}

@keyframes slideUp {
    to {
        transform: translateY(0);
    }
}

@keyframes fadeIn {
    to {
        opacity: 1;
    }
}

@keyframes float {
    0%, 100% {
        transform: translateY(0px);
    }
    50% {
        transform: translateY(-20px);
    }
}

@media (max-width: 768px) {
    .hero {
        flex-direction: column;
        text-align: center;
        padding: 2rem;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .about-content,
    .contact-content {
        grid-template-columns: 1fr;
    }
    
    .nav-links {
        display: none;
    }
    
    body {
        cursor: auto;
    }
    
    .cursor {
        display: none;
    }
}`,
      "script.js": `// Cursor personalizado
const cursor = document.querySelector('.cursor');

document.addEventListener('mousemove', (e) => {
    cursor.style.left = e.clientX + 'px';
    cursor.style.top = e.clientY + 'px';
});

// Efecto hover en elementos interactivos
const interactiveElements = document.querySelectorAll('a, button, .project-card');

interactiveElements.forEach(element => {
    element.addEventListener('mouseenter', () => {
        cursor.style.transform = 'scale(2)';
        cursor.style.background = 'rgba(99, 102, 241, 0.2)';
    });
    
    element.addEventListener('mouseleave', () => {
        cursor.style.transform = 'scale(1)';
        cursor.style.background = 'transparent';
    });
});

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animación de barras de habilidades
const skillBars = document.querySelectorAll('.skill-progress');
const aboutSection = document.querySelector('.about');

const animateSkills = () => {
    skillBars.forEach(bar => {
        const width = bar.getAttribute('data-width');
        bar.style.width = width;
    });
};

// Intersection Observer para animaciones
const observerOptions = {
    threshold: 0.3,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            if (entry.target === aboutSection) {
                animateSkills();
            }
            
            // Animación de aparición para tarjetas de proyecto
            if (entry.target.classList.contains('project-card')) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        }
    });
}, observerOptions);

// Observar secciones
observer.observe(aboutSection);

// Observar tarjetas de proyecto
document.querySelectorAll('.project-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
});

// Parallax effect para formas flotantes
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const shapes = document.querySelectorAll('.shape');
    
    shapes.forEach((shape, index) => {
        const speed = 0.5 + (index * 0.1);
        shape.style.transform = \`translateY(\${scrolled * speed}px)\`;
    });
});

// Formulario de contacto
const contactForm = document.querySelector('.contact-form');

contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Simulación de envío
    const button = contactForm.querySelector('button');
    const originalText = button.textContent;
    
    button.textContent = 'Enviando...';
    button.disabled = true;
    
    setTimeout(() => {
        button.textContent = '¡Mensaje Enviado!';
        button.style.background = '#10b981';
        
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
            button.style.background = '#6366f1';
            contactForm.reset();
        }, 2000);
    }, 1500);
});

// Efecto de escritura para el título
const heroTitle = document.querySelector('.hero-title');
const lines = heroTitle.querySelectorAll('.line');

lines.forEach((line, index) => {
    line.style.animationDelay = \`\${index * 0.2}s\`;
});

console.log('Portfolio creativo cargado correctamente!');`,
    },
  },
]

export const getTemplatesByCategory = () => {
  const categories = [...new Set(templates.map((t) => t.category))]
  return categories.map((category) => ({
    name: category,
    templates: templates.filter((t) => t.category === category),
  }))
}
