import { GoogleGenerativeAI } from "@google/generative-ai"
import { type NextRequest, NextResponse } from "next/server"

// Función para crear una respuesta de fallback
function createFallbackResponse() {
  return {
    files: {
      "index.html": `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="error-container">
        <h1>Error al generar código</h1>
        <p>Hubo un problema al procesar tu solicitud. Por favor, intenta de nuevo con una descripción más específica.</p>
        <button onclick="location.reload()">Intentar de nuevo</button>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
      "style.css": `body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background: #f5f5f5;
}

.error-container {
    max-width: 600px;
    margin: 50px auto;
    padding: 30px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    text-align: center;
}

h1 {
    color: #e74c3c;
    margin-bottom: 20px;
}

p {
    color: #666;
    margin-bottom: 30px;
    line-height: 1.6;
}

button {
    background: #3498db;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #2980b9;
}`,
      "script.js": `console.log('Error en la generación de código. Por favor, intenta de nuevo.');

// Función para recargar la página
function reloadPage() {
    location.reload();
}

// Agregar evento al botón si existe
document.addEventListener('DOMContentLoaded', function() {
    const button = document.querySelector('button');
    if (button) {
        button.addEventListener('click', reloadPage);
    }
});`,
    },
    explanation: "Error al generar el código. Se ha creado una página de error temporal.",
  }
}

export async function POST(req: NextRequest) {
  try {
    const { prompt, currentFiles, action, framework = "vanilla" } = await req.json()

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" })

    let systemPrompt = ""

    if (action === "generate") {
      systemPrompt = `Eres un experto programador que genera código ${framework === "vanilla" ? "HTML, CSS y JavaScript" : framework} completo y funcional basado en las solicitudes del usuario. 

INSTRUCCIONES IMPORTANTES:
- Genera código limpio, moderno y completamente funcional
- Siempre incluye HTML, CSS y JavaScript cuando sea necesario
- Usa CSS moderno con flexbox/grid para layouts responsivos
- Incluye interactividad con JavaScript cuando sea apropiado
- El código debe ser ejecutable inmediatamente
- NO incluyas explicaciones adicionales, solo el JSON
- Responde ÚNICAMENTE con un objeto JSON válido en este formato exacto:

{
  "files": {
    "index.html": "código HTML completo aquí",
    "style.css": "código CSS completo aquí", 
    "script.js": "código JavaScript completo aquí"
  },
  "explanation": "Breve explicación de lo que se creó"
}

Solicitud del usuario: ${prompt}`
    } else {
      systemPrompt = `Eres un experto programador que modifica código existente basado en las solicitudes del usuario.

CÓDIGO ACTUAL:
${JSON.stringify(currentFiles, null, 2)}

INSTRUCCIONES:
- Modifica solo lo necesario según la solicitud
- Mantén la funcionalidad existente
- NO incluyas explicaciones adicionales, solo el JSON
- Responde ÚNICAMENTE con un objeto JSON válido en este formato exacto:

{
  "files": {
    "index.html": "código HTML modificado",
    "style.css": "código CSS modificado",
    "script.js": "código JavaScript modificado"
  },
  "explanation": "Explicación de los cambios realizados"
}

Solicitud de modificación: ${prompt}`
    }

    // Intentar generar contenido
    try {
      console.log("Generando código con Gemini...")
      const generationResult = await model.generateContent(systemPrompt)
      const response = await generationResult.response
      const text = response.text()

      console.log("Respuesta recibida de Gemini")

      // Enfoque directo: usar una estructura predefinida y extraer solo el contenido de los archivos
      // Esto evita problemas de parseo de JSON
      try {
        // Extraer contenido de archivos usando expresiones regulares
        const htmlMatch = text.match(/"index\.html"\s*:\s*"((?:\\"|[^"])*)"/)
        const cssMatch = text.match(/"style\.css"\s*:\s*"((?:\\"|[^"])*)"/)
        const jsMatch = text.match(/"script\.js"\s*:\s*"((?:\\"|[^"])*)"/)
        const explanationMatch = text.match(/"explanation"\s*:\s*"((?:\\"|[^"])*)"/)

        // Verificar si se encontraron los patrones
        if (htmlMatch || cssMatch || jsMatch) {
          console.log("Extracción de contenido exitosa")

          // Construir respuesta manualmente
          const result = {
            files: {
              "index.html": htmlMatch
                ? htmlMatch[1].replace(/\\"/g, '"').replace(/\\n/g, "\n").replace(/\\\\/g, "\\")
                : "",
              "style.css": cssMatch
                ? cssMatch[1].replace(/\\"/g, '"').replace(/\\n/g, "\n").replace(/\\\\/g, "\\")
                : "",
              "script.js": jsMatch ? jsMatch[1].replace(/\\"/g, '"').replace(/\\n/g, "\n").replace(/\\\\/g, "\\") : "",
            },
            explanation: explanationMatch
              ? explanationMatch[1].replace(/\\"/g, '"').replace(/\\n/g, "\n").replace(/\\\\/g, "\\")
              : "Código generado exitosamente",
          }

          // Asegurar que todos los archivos requeridos estén presentes
          const requiredFiles = ["index.html", "style.css", "script.js"]
          for (const file of requiredFiles) {
            if (!result.files[file]) {
              result.files[file] = ""
            }
          }

          return NextResponse.json(result)
        } else {
          console.log("No se pudo extraer el contenido usando expresiones regulares")
          throw new Error("No se pudo extraer el contenido de los archivos")
        }
      } catch (extractError) {
        console.error("Error extrayendo contenido:", extractError)

        // Enfoque alternativo: intentar extraer bloques de código
        try {
          console.log("Intentando extraer bloques de código...")

          // Buscar bloques de código HTML, CSS y JS
          const htmlBlock = text.match(/```html\s*([\s\S]*?)\s*```/) || text.match(/<html[\s\S]*?<\/html>/)
          const cssBlock = text.match(/```css\s*([\s\S]*?)\s*```/) || text.match(/body\s*{[\s\S]*?}/)
          const jsBlock = text.match(/```js(?:cript)?\s*([\s\S]*?)\s*```/) || text.match(/function\s+\w+\s*\([\s\S]*?}/)

          if (htmlBlock || cssBlock || jsBlock) {
            console.log("Extracción de bloques de código exitosa")

            const result = {
              files: {
                "index.html": htmlBlock ? htmlBlock[1] || htmlBlock[0] : "",
                "style.css": cssBlock ? cssBlock[1] || cssBlock[0] : "",
                "script.js": jsBlock ? jsBlock[1] || jsBlock[0] : "",
              },
              explanation: "Código extraído de la respuesta",
            }

            return NextResponse.json(result)
          } else {
            console.log("No se pudieron extraer bloques de código")
            throw new Error("No se pudieron extraer bloques de código")
          }
        } catch (blockError) {
          console.error("Error extrayendo bloques de código:", blockError)
          throw new Error("Todos los métodos de extracción fallaron")
        }
      }
    } catch (error) {
      console.error("Error general en la generación:", error)
      return NextResponse.json(createFallbackResponse())
    }
  } catch (error) {
    console.error("Error en la solicitud:", error)
    return NextResponse.json(createFallbackResponse())
  }
}
