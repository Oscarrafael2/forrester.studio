"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  name: string
  email: string
  avatar?: string
}

interface Project {
  id: string
  name: string
  description: string
  files: {
    "index.html": string
    "style.css": string
    "script.js": string
  }
  framework: "vanilla" | "react" | "vue" | "svelte"
  isPublic: boolean
  createdAt: Date
  updatedAt: Date
}

interface AuthContextType {
  user: User | null
  projects: Project[]
  currentProject: Project | null
  login: (email: string) => Promise<void>
  logout: () => void
  saveProject: (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => void
  loadProject: (id: string) => void
  deleteProject: (id: string) => void
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [currentProject, setCurrentProject] = useState<Project | null>(null)

  useEffect(() => {
    // Cargar datos del localStorage
    const savedUser = localStorage.getItem("codeai_user")
    const savedProjects = localStorage.getItem("codeai_projects")

    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    if (savedProjects) {
      setProjects(JSON.parse(savedProjects))
    }
  }, [])

  const login = async (email: string) => {
    // Simulación de login - en producción usarías un servicio real
    const newUser: User = {
      id: Date.now().toString(),
      name: email.split("@")[0],
      email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
    }
    setUser(newUser)
    localStorage.setItem("codeai_user", JSON.stringify(newUser))
  }

  const logout = () => {
    setUser(null)
    setCurrentProject(null)
    localStorage.removeItem("codeai_user")
  }

  const saveProject = (projectData: Omit<Project, "id" | "createdAt" | "updatedAt">) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const updatedProjects = [...projects, newProject]
    setProjects(updatedProjects)
    setCurrentProject(newProject)
    localStorage.setItem("codeai_projects", JSON.stringify(updatedProjects))
  }

  const loadProject = (id: string) => {
    const project = projects.find((p) => p.id === id)
    if (project) {
      setCurrentProject(project)
    }
  }

  const deleteProject = (id: string) => {
    const updatedProjects = projects.filter((p) => p.id !== id)
    setProjects(updatedProjects)
    localStorage.setItem("codeai_projects", JSON.stringify(updatedProjects))

    if (currentProject?.id === id) {
      setCurrentProject(null)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        projects,
        currentProject,
        login,
        logout,
        saveProject,
        loadProject,
        deleteProject,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
