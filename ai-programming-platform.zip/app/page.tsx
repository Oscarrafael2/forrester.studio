"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Send,
  Play,
  Download,
  Code,
  Eye,
  Sparkles,
  Globe,
  Smartphone,
  Gamepad2,
  Calculator,
  Camera,
  ShoppingCart,
  Music,
  Calendar,
  ChevronRight,
  MessageSquare,
  FileCode,
  Settings,
  Github,
  Share2,
  Zap,
  Save,
  FolderOpen,
  Sun,
  Moon,
  Monitor,
  Terminal,
  Layout,
  User,
  LogOut,
  Trash2,
  ExternalLink,
  Maximize2,
  Minimize2,
  AlertCircle,
  Info,
} from "lucide-react"
import dynamic from "next/dynamic"
import { useAuth } from "@/lib/auth"
import { useTheme } from "@/lib/theme"
import { getTemplatesByCategory, type Template } from "@/lib/templates"

const MonacoEditor = dynamic(() => import("@monaco-editor/react"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
    </div>
  ),
})

interface FileSystem {
  "index.html": string
  "style.css": string
  "script.js": string
}

interface Message {
  role: "user" | "assistant" | "error" | "system"
  content: string
  files?: FileSystem
}

const suggestions = [
  { icon: Globe, text: "Crea una landing page moderna", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  {
    icon: Smartphone,
    text: "Diseña una app móvil responsive",
    color: "bg-green-500/10 text-green-400 border-green-500/20",
  },
  { icon: Gamepad2, text: "Haz un juego de memoria", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  {
    icon: Calculator,
    text: "Construye una calculadora",
    color: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  },
  { icon: Camera, text: "Galería de fotos interactiva", color: "bg-pink-500/10 text-pink-400 border-pink-500/20" },
  {
    icon: ShoppingCart,
    text: "E-commerce con carrito",
    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  },
  { icon: Music, text: "Reproductor de música", color: "bg-red-500/10 text-red-400 border-red-500/20" },
  {
    icon: Calendar,
    text: "App de calendario y tareas",
    color: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
  },
]

export default function AIProgrammingPlatform() {
  const { user, projects, currentProject, login, logout, saveProject, loadProject, deleteProject } = useAuth()
  const { theme, setTheme, isDark } = useTheme()

  const [messages, setMessages] = useState<Message[]>([
    {
      role: "system",
      content: "Bienvenido a CodeAI. Describe la aplicación web que quieres crear y la generaré para ti.",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showEditor, setShowEditor] = useState(false)
  const [files, setFiles] = useState<FileSystem>({
    "index.html": "",
    "style.css": "",
    "script.js": "",
  })
  const [activeFile, setActiveFile] = useState<keyof FileSystem>("index.html")
  const [activeTab, setActiveTab] = useState("code")
  const [showChat, setShowChat] = useState(true)
  const [showTerminal, setShowTerminal] = useState(false)
  const [terminalOutput, setTerminalOutput] = useState<string[]>([])
  const [showTemplates, setShowTemplates] = useState(false)
  const [showLogin, setShowLogin] = useState(false)
  const [loginEmail, setLoginEmail] = useState("")
  const [projectName, setProjectName] = useState("")
  const [framework, setFramework] = useState<"vanilla" | "react" | "vue" | "svelte">("vanilla")
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const iframeRef = useRef<HTMLIFrameElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)

  // Scroll al final del chat cuando hay nuevos mensajes
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Atajos de teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "s":
            e.preventDefault()
            handleSaveProject()
            break
          case "r":
            e.preventDefault()
            updatePreview()
            break
          case "/":
            e.preventDefault()
            // Comentar línea (implementar con Monaco)
            break
          case "d":
            e.preventDefault()
            // Duplicar línea (implementar con Monaco)
            break
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  const generateCode = async (prompt: string, isModification = false) => {
    setIsLoading(true)
    setErrorMessage(null)

    try {
      // Mostrar mensaje de generación
      setMessages((prev) => [
        ...prev,
        {
          role: "system",
          content: "Generando código, esto puede tomar unos momentos...",
        },
      ])

      const response = await fetch("/api/generate-code", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          currentFiles: isModification ? files : null,
          action: isModification ? "modify" : "generate",
          framework,
        }),
      })

      // Eliminar el mensaje de generación
      setMessages((prev) => prev.filter((msg) => msg.content !== "Generando código, esto puede tomar unos momentos..."))

      if (!response.ok) {
        throw new Error(`Error de servidor: ${response.status}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      if (data.files) {
        setFiles(data.files)
        setShowEditor(true)

        // Verificar si la respuesta es un error (página de error)
        const isErrorResponse = data.explanation && data.explanation.includes("Error al generar")

        if (isErrorResponse) {
          setMessages((prev) => [
            ...prev,
            {
              role: "error",
              content: data.explanation,
              files: data.files,
            },
          ])
          setErrorMessage(
            "Hubo un problema al generar el código. Por favor, intenta con una descripción más específica.",
          )
        } else {
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content: data.explanation || "Código generado exitosamente",
              files: data.files,
            },
          ])

          // Auto-guardar si hay usuario logueado
          if (user && !currentProject) {
            const projectData = {
              name: projectName || "Nuevo Proyecto",
              description: prompt.slice(0, 100) + "...",
              files: data.files,
              framework,
              isPublic: false,
            }
            saveProject(projectData)
          }
        }
      } else {
        throw new Error("No se recibieron archivos en la respuesta")
      }
    } catch (error) {
      console.error("Error en generateCode:", error)
      setMessages((prev) => [
        ...prev,
        {
          role: "error",
          content: `Error al generar el código: ${error instanceof Error ? error.message : "Error desconocido"}. Por favor, intenta de nuevo con una descripción más específica.`,
        },
      ])
      setErrorMessage("Error al generar el código. Por favor, intenta de nuevo.")
    }

    setIsLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])

    const isModification = showEditor && files["index.html"] !== ""
    const userPrompt = input
    setInput("")
    await generateCode(userPrompt, isModification)
  }

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion)
  }

  const handleTemplateSelect = (template: Template) => {
    setFiles(template.files)
    setFramework(template.framework)
    setShowEditor(true)
    setShowTemplates(false)
    setMessages([
      {
        role: "system",
        content: "Bienvenido a CodeAI. Describe la aplicación web que quieres crear y la generaré para ti.",
      },
      {
        role: "assistant",
        content: `Template "${template.name}" cargado exitosamente. Puedes modificarlo o pedir cambios.`,
        files: template.files,
      },
    ])
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!loginEmail.trim()) return

    await login(loginEmail)
    setShowLogin(false)
    setLoginEmail("")
  }

  const handleSaveProject = () => {
    if (!user) {
      setShowLogin(true)
      return
    }

    const projectData = {
      name: projectName || "Nuevo Proyecto",
      description: messages.find((m) => m.role === "user")?.content || "Proyecto sin descripción",
      files,
      framework,
      isPublic: false,
    }
    saveProject(projectData)
  }

  const updatePreview = () => {
    if (iframeRef.current) {
      const iframe = iframeRef.current
      const doc = iframe.contentDocument || iframe.contentWindow?.document
      if (doc) {
        doc.open()
        doc.write(
          files["index.html"]
            .replace('<link rel="stylesheet" href="style.css">', `<style>${files["style.css"]}</style>`)
            .replace('<script src="script.js"></script>', `<script>${files["script.js"]}</script>`),
        )
        doc.close()
      }
    }
  }

  const executeTerminalCommand = (command: string) => {
    const newOutput = [...terminalOutput, `$ ${command}`]

    switch (command.toLowerCase()) {
      case "help":
        newOutput.push("Comandos disponibles: help, clear, ls, npm install, npm run dev, git status")
        break
      case "clear":
        setTerminalOutput([])
        return
      case "ls":
        newOutput.push("index.html  style.css  script.js")
        break
      case "npm install":
        newOutput.push("📦 Instalando dependencias...")
        newOutput.push("✅ Dependencias instaladas correctamente")
        break
      case "npm run dev":
        newOutput.push("🚀 Servidor de desarrollo iniciado en http://localhost:3000")
        break
      case "git status":
        newOutput.push("En la rama main")
        newOutput.push("Cambios no confirmados:")
        newOutput.push("  modificado: index.html")
        newOutput.push("  modificado: style.css")
        break
      default:
        newOutput.push(`Comando no reconocido: ${command}`)
    }

    setTerminalOutput(newOutput)
  }

  const deployToVercel = async () => {
    // Simulación de deploy
    setTerminalOutput((prev) => [
      ...prev,
      "$ vercel deploy",
      "🔄 Desplegando a Vercel...",
      "✅ Desplegado exitosamente!",
      "🌐 URL: https://tu-proyecto.vercel.app",
    ])
    setShowTerminal(true)
  }

  useEffect(() => {
    if (showEditor) {
      updatePreview()
    }
  }, [files, showEditor])

  const downloadFiles = () => {
    Object.entries(files).forEach(([filename, content]) => {
      const blob = new Blob([content], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = filename
      a.click()
      URL.revokeObjectURL(url)
    })
  }

  const getLanguage = (filename: keyof FileSystem) => {
    if (filename.endsWith(".html")) return "html"
    if (filename.endsWith(".css")) return "css"
    if (filename.endsWith(".js")) return "javascript"
    return "plaintext"
  }

  const getFileIcon = (filename: keyof FileSystem) => {
    if (filename.endsWith(".html")) return "🌐"
    if (filename.endsWith(".css")) return "🎨"
    if (filename.endsWith(".js")) return "⚙️"
    return "📄"
  }

  const getDeviceClass = () => {
    switch (previewDevice) {
      case "mobile":
        return "w-[375px] h-[667px]"
      case "tablet":
        return "w-[768px] h-[1024px]"
      default:
        return "w-full h-full"
    }
  }

  const getMessageStyle = (role: string) => {
    switch (role) {
      case "user":
        return "bg-blue-600/10 border border-blue-500/20"
      case "error":
        return "bg-red-500/10 border border-red-500/20"
      case "system":
        return isDark ? "bg-gray-800/50 border-gray-700/50 border" : "bg-gray-100 border-gray-200/50 border"
      default:
        return isDark ? "bg-[#1A1A1A] border-[#333333] border" : "bg-white border-gray-200 border"
    }
  }

  const getMessageIcon = (role: string) => {
    switch (role) {
      case "user":
        return null
      case "assistant":
        return (
          <Badge className="bg-blue-500/20 text-blue-400 text-[10px] px-1.5 py-0">
            <Zap className="w-3 h-3 mr-1" />
            Gemini
          </Badge>
        )
      case "error":
        return (
          <Badge className="bg-red-500/20 text-red-400 text-[10px] px-1.5 py-0">
            <AlertCircle className="w-3 h-3 mr-1" />
            Error
          </Badge>
        )
      case "system":
        return (
          <Badge
            className={
              isDark
                ? "bg-gray-700/50 text-gray-400 text-[10px] px-1.5 py-0"
                : "bg-gray-200/50 text-gray-500 text-[10px] px-1.5 py-0"
            }
          >
            <Info className="w-3 h-3 mr-1" />
            Sistema
          </Badge>
        )
      default:
        return null
    }
  }

  if (!showEditor) {
    return (
      <div className={"min-h-screen " + (isDark ? "bg-black text-white" : "bg-white text-black") + " flex flex-col"}>
        {/* Header */}
        <header className={"border-b " + (isDark ? "border-gray-800" : "border-gray-200") + " p-4"}>
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-blue-400" />
              <span className="text-xl font-bold">CodeAI</span>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <div className="flex items-center gap-3">
                  <img src={user.avatar || "/placeholder.svg"} alt={user.name} className="w-8 h-8 rounded-full" />
                  <span className="text-sm">{user.name}</span>
                  <Button variant="ghost" size="sm" onClick={logout}>
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setShowLogin(true)}>
                  <User className="w-4 h-4 mr-2" />
                  Iniciar Sesión
                </Button>
              )}
              <Select value={theme} onValueChange={setTheme}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dark">
                    <div className="flex items-center gap-2">
                      <Moon className="w-4 h-4" />
                      Oscuro
                    </div>
                  </SelectItem>
                  <SelectItem value="light">
                    <div className="flex items-center gap-2">
                      <Sun className="w-4 h-4" />
                      Claro
                    </div>
                  </SelectItem>
                  <SelectItem value="auto">
                    <div className="flex items-center gap-2">
                      <Monitor className="w-4 h-4" />
                      Auto
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <Badge
                variant="outline"
                className={isDark ? "border-gray-700 text-gray-400" : "border-gray-300 text-gray-600"}
              >
                Powered by Gemini
              </Badge>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-4xl w-full space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4">
              <h1
                className={
                  "text-5xl md:text-6xl font-bold bg-gradient-to-r " +
                  (isDark ? "from-white to-gray-400" : "from-gray-900 to-gray-600") +
                  " bg-clip-text text-transparent"
                }
              >
                Construye cualquier aplicación web, rápido.
              </h1>
              <p className={"text-xl " + (isDark ? "text-gray-400" : "text-gray-600") + " max-w-2xl mx-auto"}>
                CodeAI genera aplicaciones web completas usando IA. Describe lo que quieres y obtén código HTML, CSS y
                JavaScript listo para usar.
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex justify-center gap-4">
              <Button onClick={() => setShowTemplates(true)} variant="outline" className="flex items-center gap-2">
                <Layout className="w-4 h-4" />
                Templates
              </Button>
              {user && projects.length > 0 && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-2">
                      <FolderOpen className="w-4 h-4" />
                      Mis Proyectos
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Mis Proyectos</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 max-h-96 overflow-y-auto">
                      {projects.map((project) => (
                        <div
                          key={project.id}
                          className={
                            "p-4 border rounded-lg " +
                            (isDark ? "border-gray-700 bg-gray-800" : "border-gray-200 bg-gray-50")
                          }
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="font-medium">{project.name}</h3>
                              <p className={"text-sm " + (isDark ? "text-gray-400" : "text-gray-600")}>
                                {project.description}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline">{project.framework}</Badge>
                                <span className={"text-xs " + (isDark ? "text-gray-500" : "text-gray-400")}>
                                  {new Date(project.updatedAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => {
                                  loadProject(project.id)
                                  setFiles(project.files)
                                  setFramework(project.framework)
                                  setShowEditor(true)
                                }}
                              >
                                Abrir
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => deleteProject(project.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex gap-4 mb-4">
                <Input
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="Nombre del proyecto (opcional)"
                  className={isDark ? "bg-gray-900/50 border-gray-700" : "bg-gray-100 border-gray-300"}
                />
                <Select
                  value={framework}
                  onValueChange={(value) => setFramework(value as "vanilla" | "react" | "vue" | "svelte")}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vanilla">HTML/CSS/JS</SelectItem>
                    <SelectItem value="react">React</SelectItem>
                    <SelectItem value="vue">Vue.js</SelectItem>
                    <SelectItem value="svelte">Svelte</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="relative">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Describe la aplicación web que quieres crear..."
                  className={
                    "min-h-[120px] " +
                    (isDark
                      ? "bg-gray-900/50 border-gray-700 text-white placeholder-gray-500"
                      : "bg-gray-100 border-gray-300 text-black placeholder-gray-400") +
                    " text-lg resize-none focus:border-blue-500 focus:ring-blue-500/20"
                  }
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  disabled={isLoading || !input.trim()}
                  className="absolute bottom-3 right-3 bg-blue-600 hover:bg-blue-700"
                >
                  {isLoading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <div className="flex items-center justify-center">
                <Badge
                  variant="outline"
                  className={isDark ? "border-gray-700 text-gray-400" : "border-gray-300 text-gray-600"}
                >
                  <Globe className="w-3 h-3 mr-1" />
                  Público
                </Badge>
              </div>
            </form>

            {/* Error Message */}
            {errorMessage && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Suggestions */}
            <div className="space-y-4">
              <p className={"text-center " + (isDark ? "text-gray-500" : "text-gray-400") + " text-sm"}>
                O prueba una de estas ideas:
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                {suggestions.map((suggestion, index) => {
                  const Icon = suggestion.icon
                  return (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion.text)}
                      className={
                        "flex items-center gap-2 px-4 py-2 rounded-full border transition-all hover:scale-105 " +
                        suggestion.color
                      }
                      disabled={isLoading}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{suggestion.text}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="text-center space-y-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto" />
                <p className={isDark ? "text-gray-400" : "text-gray-600"}>Generando tu aplicación...</p>
              </div>
            )}
          </div>
        </main>

        {/* Footer */}
        <footer className={"border-t " + (isDark ? "border-gray-800" : "border-gray-200") + " p-4"}>
          <div className={"max-w-4xl mx-auto text-center " + (isDark ? "text-gray-500" : "text-gray-400") + " text-sm"}>
            Construido con ❤️ usando Next.js y Gemini AI
          </div>
        </footer>

        {/* Templates Dialog */}
        <Dialog open={showTemplates} onOpenChange={setShowTemplates}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Selecciona un Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {getTemplatesByCategory().map((category) => (
                <div key={category.name}>
                  <h3 className="text-lg font-semibold mb-3">{category.name}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {category.templates.map((template) => (
                      <div
                        key={template.id}
                        className={
                          "p-4 border rounded-lg cursor-pointer transition-all hover:shadow-lg " +
                          (isDark
                            ? "border-gray-700 bg-gray-800 hover:border-blue-500"
                            : "border-gray-200 bg-white hover:border-blue-400")
                        }
                        onClick={() => handleTemplateSelect(template)}
                      >
                        <div
                          className={
                            "w-full h-32 " +
                            (isDark ? "bg-gray-700" : "bg-gray-100") +
                            " rounded mb-3 flex items-center justify-center text-2xl"
                          }
                        >
                          🎨
                        </div>
                        <h4 className="font-medium mb-2">{template.name}</h4>
                        <p className={"text-sm " + (isDark ? "text-gray-400" : "text-gray-600") + " mb-3"}>
                          {template.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline">{template.framework}</Badge>
                          <Button size="sm">Usar Template</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* Login Dialog */}
        <Dialog open={showLogin} onOpenChange={setShowLogin}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Iniciar Sesión</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="tu@email.com"
                required
              />
              <Button type="submit" className="w-full">
                Iniciar Sesión
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    )
  }

  return (
    <div className={"h-screen flex flex-col " + (isDark ? "bg-[#0A0A0A] text-white" : "bg-white text-black")}>
      {/* Header */}
      <div
        className={
          (isDark ? "bg-[#111111] border-[#222222]" : "bg-gray-100 border-gray-200") +
          " p-3 border-b flex items-center justify-between"
        }
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowEditor(false)}
            className="flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors"
          >
            <Sparkles className="w-5 h-5" />
            <span className="font-bold">CodeAI</span>
          </button>
          <div className={(isDark ? "border-[#333333]" : "border-gray-300") + " h-4 border-r mx-1"}></div>
          <div
            className={
              (isDark ? "bg-[#1A1A1A] border-[#333333]" : "bg-white border-gray-200") +
              " flex items-center gap-1 px-3 py-1 rounded-md border"
            }
          >
            <FileCode className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-medium">{currentProject?.name || projectName || "Proyecto"}</span>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={() => setShowChat(!showChat)}
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={updatePreview}
          >
            <Play className="w-4 h-4 mr-2" />
            Ejecutar
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={handleSaveProject}
          >
            <Save className="w-4 h-4 mr-2" />
            Guardar
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={downloadFiles}
          >
            <Download className="w-4 h-4 mr-2" />
            Descargar
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={deployToVercel}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Deploy
          </Button>
          <div className={(isDark ? "border-[#333333]" : "border-gray-300") + " h-4 border-r mx-1"}></div>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 px-3 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
            onClick={() => setShowTerminal(!showTerminal)}
          >
            <Terminal className="w-4 h-4 mr-2" />
            Terminal
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 w-8 p-0 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
          >
            <Settings className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 w-8 p-0 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
          >
            <Github className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={
              "h-8 w-8 p-0 " +
              (isDark
                ? "text-gray-400 hover:text-white hover:bg-[#222222]"
                : "text-gray-600 hover:text-black hover:bg-gray-100")
            }
          >
            <Share2 className="w-4 h-4" />
          </Button>
          {user && (
            <div className="flex items-center gap-2">
              <img src={user.avatar || "/placeholder.svg"} alt={user.name} className="w-6 h-6 rounded-full" />
              <span className="text-sm">{user.name}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        {showChat && (
          <div
            className={
              "w-80 " +
              (isDark ? "bg-[#111111] border-[#222222]" : "bg-gray-50 border-gray-200") +
              " border-r flex flex-col"
            }
          >
            <div
              className={
                (isDark ? "border-[#222222]" : "border-gray-200") + " p-3 border-b flex items-center justify-between"
              }
            >
              <h2 className="text-sm font-medium flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-blue-400" />
                Conversación
              </h2>
              <Button
                size="sm"
                variant="ghost"
                className={
                  "h-6 w-6 p-0 " +
                  (isDark
                    ? "text-gray-500 hover:text-white hover:bg-[#222222]"
                    : "text-gray-400 hover:text-black hover:bg-gray-100")
                }
                onClick={() => setShowChat(false)}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={"p-3 rounded-lg " + getMessageStyle(message.role)}>
                  <div
                    className={
                      "text-xs font-medium mb-2 " +
                      (isDark ? "text-gray-400" : "text-gray-500") +
                      " flex items-center justify-between"
                    }
                  >
                    <span>{message.role === "user" ? "Tú" : message.role === "system" ? "Sistema" : "CodeAI"}</span>
                    {getMessageIcon(message.role)}
                  </div>
                  <div className={"text-sm " + (message.role === "error" ? "text-red-400" : "")}>{message.content}</div>
                </div>
              ))}
              {isLoading && (
                <div
                  className={
                    (isDark ? "bg-[#1A1A1A] border-[#333333]" : "bg-white border-gray-200") + " border p-3 rounded-lg"
                  }
                >
                  <div
                    className={
                      "text-xs font-medium mb-2 " +
                      (isDark ? "text-gray-400" : "text-gray-500") +
                      " flex items-center justify-between"
                    }
                  >
                    <span>CodeAI</span>
                    <Badge className="bg-blue-500/20 text-blue-400 text-[10px] px-1.5 py-0">
                      <Zap className="w-3 h-3 mr-1" />
                      Gemini
                    </Badge>
                  </div>
                  <div className="text-sm flex items-center gap-2">
                    <div className="animate-pulse flex space-x-1">
                      <div className="h-1.5 w-1.5 bg-blue-400 rounded-full"></div>
                      <div className="h-1.5 w-1.5 bg-blue-400 rounded-full"></div>
                      <div className="h-1.5 w-1.5 bg-blue-400 rounded-full"></div>
                    </div>
                    <span className={isDark ? "text-gray-400" : "text-gray-500"}>Generando código...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <form
              onSubmit={handleSubmit}
              className={(isDark ? "border-[#222222]" : "border-gray-200") + " p-3 border-t"}
            >
              <div className="flex flex-col gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Pide cambios o mejoras..."
                  className={
                    (isDark
                      ? "bg-[#1A1A1A] border-[#333333] text-white placeholder-gray-500"
                      : "bg-white border-gray-200 text-black placeholder-gray-400") +
                    " resize-none min-h-[60px] text-sm"
                  }
                  disabled={isLoading}
                />
                <div className="flex justify-end">
                  <Button
                    type="submit"
                    disabled={isLoading || !input.trim()}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isLoading ? (
                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white" />
                    ) : (
                      <>
                        <Send className="w-3 h-3 mr-2" />
                        Enviar
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </form>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div
              className={
                (isDark ? "bg-[#111111] border-[#222222]" : "bg-gray-100 border-gray-200") +
                " border-b flex items-center justify-between"
              }
            >
              <TabsList className="bg-transparent rounded-none h-auto p-0">
                <TabsTrigger
                  value="code"
                  className={
                    (isDark ? "data-[state=active]:bg-[#0A0A0A]" : "data-[state=active]:bg-white") +
                    " data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none rounded-none px-4 py-2 h-10"
                  }
                >
                  <Code className="w-4 h-4 mr-2" />
                  Editor
                </TabsTrigger>
                <TabsTrigger
                  value="preview"
                  className={
                    (isDark ? "data-[state=active]:bg-[#0A0A0A]" : "data-[state=active]:bg-white") +
                    " data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:shadow-none rounded-none px-4 py-2 h-10"
                  }
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Vista Previa
                </TabsTrigger>
              </TabsList>

              {activeTab === "preview" && (
                <div className="flex items-center gap-2 px-4">
                  <Select
                    value={previewDevice}
                    onValueChange={(value) => setPreviewDevice(value as "desktop" | "tablet" | "mobile")}
                  >
                    <SelectTrigger className="w-[120px] h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desktop">
                        <div className="flex items-center gap-2">
                          <Monitor className="w-4 h-4" />
                          Desktop
                        </div>
                      </SelectItem>
                      <SelectItem value="tablet">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-4 h-4 rotate-90" />
                          Tablet
                        </div>
                      </SelectItem>
                      <SelectItem value="mobile">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-4 h-4" />
                          Mobile
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsFullscreen(!isFullscreen)}
                    className="h-8 w-8 p-0"
                  >
                    {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </Button>
                </div>
              )}
            </div>

            <TabsContent value="code" className="flex-1 flex flex-col m-0 overflow-hidden">
              {/* File Tabs */}
              <div
                className={
                  (isDark ? "bg-[#111111] border-[#222222]" : "bg-gray-100 border-gray-200") + " border-b flex"
                }
              >
                {Object.keys(files).map((filename) => (
                  <button
                    key={filename}
                    onClick={() => setActiveFile(filename as keyof FileSystem)}
                    className={
                      "px-4 py-2 text-sm border-r " +
                      (isDark ? "border-[#222222]" : "border-gray-200") +
                      " transition-colors flex items-center gap-2 " +
                      (activeFile === filename
                        ? (isDark ? "bg-[#0A0A0A] text-white" : "bg-white text-black") + " border-b-2 border-b-blue-500"
                        : isDark
                          ? "bg-[#111111] text-gray-400 hover:text-white hover:bg-[#1A1A1A]"
                          : "bg-gray-100 text-gray-600 hover:text-black hover:bg-gray-200")
                    }
                    style={{
                      marginBottom: activeFile === filename ? "-1px" : "0",
                      paddingBottom: activeFile === filename ? "calc(0.5rem - 2px)" : "0.5rem",
                    }}
                  >
                    <span>{getFileIcon(filename as keyof FileSystem)}</span>
                    <span>{filename}</span>
                  </button>
                ))}
              </div>

              {/* Code Editor */}
              <div className="flex-1 overflow-hidden">
                <MonacoEditor
                  height="100%"
                  language={getLanguage(activeFile)}
                  theme={isDark ? "vs-dark" : "light"}
                  value={files[activeFile]}
                  onChange={(value) => {
                    if (value !== undefined) {
                      setFiles((prev) => ({
                        ...prev,
                        [activeFile]: value,
                      }))
                    }
                  }}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    wordWrap: "on",
                    automaticLayout: true,
                    scrollBeyondLastLine: false,
                    renderLineHighlight: "all",
                    lineNumbers: "on",
                    lineDecorationsWidth: 10,
                    folding: true,
                    padding: { top: 15 },
                    contextmenu: true,
                    quickSuggestions: true,
                    suggestOnTriggerCharacters: true,
                  }}
                />
              </div>
            </TabsContent>

            <TabsContent value="preview" className="flex-1 m-0 overflow-hidden">
              <div
                className={
                  "h-full " +
                  (isDark ? "bg-[#111111]" : "bg-gray-100") +
                  " flex items-center justify-center " +
                  (isFullscreen ? "fixed inset-0 z-50" : "")
                }
              >
                <div
                  className={
                    getDeviceClass() +
                    " " +
                    (previewDevice !== "desktop" ? "border border-gray-300 rounded-lg overflow-hidden shadow-lg" : "")
                  }
                >
                  <iframe ref={iframeRef} className="w-full h-full border-0 bg-white" title="Preview" />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Terminal */}
      {showTerminal && (
        <div
          className={
            "h-64 " + (isDark ? "bg-black border-[#333333]" : "bg-gray-900 border-gray-600") + " border-t flex flex-col"
          }
        >
          <div
            className={
              (isDark ? "bg-[#111111] border-[#333333]" : "bg-gray-800 border-gray-600") +
              " p-2 border-b flex items-center justify-between"
            }
          >
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-green-400" />
              <span className="text-sm text-white">Terminal</span>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowTerminal(false)}
              className="h-6 w-6 p-0 text-gray-400 hover:text-white"
            >
              <ChevronRight className="w-4 h-4 rotate-90" />
            </Button>
          </div>
          <div className="flex-1 p-3 overflow-y-auto font-mono text-sm text-green-400">
            {terminalOutput.map((line, index) => (
              <div key={index} className="mb-1">
                {line}
              </div>
            ))}
            <div className="flex items-center">
              <span className="text-blue-400">$ </span>
              <input
                type="text"
                className="bg-transparent border-none outline-none flex-1 text-green-400 ml-1"
                placeholder="Escribe un comando..."
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    const command = e.currentTarget.value
                    if (command.trim()) {
                      executeTerminalCommand(command)
                      e.currentTarget.value = ""
                    }
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Status Bar */}
      <div
        className={
          (isDark ? "bg-[#111111] border-[#222222]" : "bg-gray-100 border-gray-200") +
          " border-t p-1.5 px-3 flex items-center justify-between text-xs " +
          (isDark ? "text-gray-400" : "text-gray-600")
        }
      >
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            Listo
          </span>
          <span>{framework.toUpperCase()}</span>
          <span>{Object.keys(files).length} archivos</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Gemini AI</span>
          <span>CodeAI v2.0</span>
          <span>Ctrl+S: Guardar | Ctrl+R: Ejecutar</span>
        </div>
      </div>
    </div>
  )
}
